const s=globalThis.__sveltekit_1f280r6?.base??"/microfolio",a=globalThis.__sveltekit_1f280r6?.assets??s??"";export{a,s as b};
