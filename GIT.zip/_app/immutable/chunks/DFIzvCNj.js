const s=globalThis.__sveltekit_ec9uad?.base??"/microfolio",a=globalThis.__sveltekit_ec9uad?.assets??s??"";export{a,s as b};
