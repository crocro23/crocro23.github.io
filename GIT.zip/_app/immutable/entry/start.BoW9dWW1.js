import{l as o,a as r}from"../chunks/C7IBD4bW.js";export{o as load_css,r as start};
